from django.db import models


class City(models.Model):
    name=models.CharField(max_length=50)
    lat=models.FloatField()
    lng=models.FloatField()
    image=models.CharField(max_length=50)
