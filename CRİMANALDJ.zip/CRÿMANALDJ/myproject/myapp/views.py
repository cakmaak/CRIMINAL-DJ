from django.http import HttpResponse
from django.shortcuts import render
from myapp.models import City

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import requests
import json
from datetime import datetime
from collections import Counter

def city_dropdown_view(request):
    cities = City.objects.all()  # Veritabanından tüm şehirleri çek
    return render(request, "index.html", {"cities": cities})  # "cities" olarak gönderiyoruz


@csrf_exempt
def crime_search(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'Geçersiz istek yöntemi, sadece POST desteklenir.'}, status=400)

    try:
        # JSON verilerini al ve decode et
        data = json.loads(request.body.decode('utf-8'))
        lat = data.get('lat')
        lng = data.get('lng')
        date = data.get('date')

        # Eksik veri kontrolü
        if not lat or not lng or not date:
            return JsonResponse({'error': 'Lütfen tüm alanları doldurun!'}, status=400)

        # API'ye istek at
        api_url = 'https://data.police.uk/api/crimes-street/all-crime'
        params = {'date': date, 'lat': lat, 'lng': lng}

        print(f"API'ye gönderilen istek: {api_url} - Parametreler: {params}")  # Debugging

        response = requests.get(api_url, params=params)

        print(f"API Yanıt Kodu: {response.status_code}")  # Debugging
        print(f"API Yanıt İçeriği: {response.text}")  # Debugging

        if response.status_code != 200:
            return JsonResponse({'error': f'API isteği başarısız oldu. Hata kodu: {response.status_code}, İçerik: {response.text}'}, status=500)

        # API yanıtını JSON olarak işle
        result = response.json()

        if not result:
            return JsonResponse({'result': 'Bu tarihte ve konumda suç kaydı bulunamadı.'})

        # Suç kategorilerini say
        categories = [item['category'] for item in result]
        category_counts = Counter(categories)
        formatted_result = "\n".join([f"{category}: {count}" for category, count in category_counts.items()])

        return JsonResponse({'result': formatted_result})

    except json.JSONDecodeError:
        return JsonResponse({'error': 'JSON format hatası, lütfen geçerli bir JSON gönderin.'}, status=400)
    except Exception as e:
        return JsonResponse({'error': f'Bir hata oluştu: {str(e)}'}, status=500)


    

# Create your views here.

#def index(request):
   
 #   return render(request,"index.html")

def index(request):
    return render(request, 'index.html')

def blog_details(request,id):
   blog=City.objects.get(id=id)
   return render(request,"blog-details.html",{
       "blog":blog
    } )




    


