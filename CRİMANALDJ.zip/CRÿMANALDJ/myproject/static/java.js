<script>
  function selectCity(cityName) {
    // Butonun üzerindeki metni, seçilen şehir adıyla değiştir.
    var button = document.getElementById("cityButton");
    button.textContent = cityName;  // Seçilen şehir ismini butonun metni olarak değiştir
  }
</script>
{% block css_files %}
<link href="{% static 'css/style.css' %}" rel="stylesheet">
{% endblock %}